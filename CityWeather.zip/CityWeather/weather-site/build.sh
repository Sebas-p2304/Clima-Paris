#!/usr/bin/bash
emacs -Q --script build-site.el
